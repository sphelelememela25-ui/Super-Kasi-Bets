import 'package:flutter/material.dart';

void main() => runApp(const SuperKasiBetsApp());

const Color forest = Color(0xFF073B2A);
const Color deep = Color(0xFF061B15);
const Color gold = Color(0xFFFFC928);

class SuperKasiBetsApp extends StatelessWidget {
  const SuperKasiBetsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Super Kasi Bets',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: deep,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(backgroundColor: forest, foregroundColor: Colors.white),
      ),
      home: const DemoHome(),
    );
  }
}

class DemoHome extends StatefulWidget {
  const DemoHome({super.key});
  @override
  State<DemoHome> createState() => _DemoHomeState();
}

class _DemoHomeState extends State<DemoHome> {
  int tab = 0;
  double balance = 150;
  final List<String> slip = [];

  void addPick(String pick) {
    setState(() => slip.add(pick));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$pick added to demo slip')));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _footballPage(),
      _gamesPage(),
      _myBetsPage(),
      _adminPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [Icon(Icons.shield, color: gold), SizedBox(width: 8), Text('SUPER KASI BETS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1))]),
        actions: [IconButton(onPressed: _showAccount, icon: const Icon(Icons.account_circle_outlined))],
      ),
      body: SafeArea(child: Column(children: [
        _balanceCard(),
        Expanded(child: pages[tab]),
      ])),
      bottomNavigationBar: NavigationBar(
        backgroundColor: forest,
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sports_soccer), label: 'Football'),
          NavigationDestination(icon: Icon(Icons.casino_outlined), label: 'Free Games'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'My Bets'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _balanceCard() => Container(
    margin: const EdgeInsets.fromLTRB(16, 14, 16, 10), padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(gradient: const LinearGradient(colors: [forest, Color(0xFF126344)]), borderRadius: BorderRadius.circular(18), border: Border.all(color: gold.withOpacity(.65))),
    child: Row(children: [
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('DEMO WALLET', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.4)), SizedBox(height: 4), Text('Virtual credits only', style: TextStyle(color: Colors.white70, fontSize: 12))]),
      Text('R ${balance.toStringAsFixed(2)}', style: const TextStyle(color: gold, fontSize: 25, fontWeight: FontWeight.w900)),
    ]),
  );

  Widget _footballPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const _SectionTitle('TODAY\'S DEMO FIXTURES', subtitle: 'Illustrative teams and odds — not live markets'),
    _matchCard('Arsenal', 'Chelsea', '19:30', ['2.10', '3.20', '3.40']),
    _matchCard('Barcelona', 'Real Madrid', '21:00', ['2.45', '3.50', '2.70']),
    _matchCard('Orlando Pirates', 'Kaizer Chiefs', 'Demo fixture', ['1.95', '3.10', '3.80']),
    const SizedBox(height: 10),
    const Text('Demo picks do not represent real betting odds or a real sporting event.', style: TextStyle(color: Colors.white54, fontSize: 11)),
  ]);

  Widget _matchCard(String home, String away, String time, List<String> odds) => Card(
    color: const Color(0xFF102B21), margin: const EdgeInsets.only(top: 12),
    child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.sports_soccer, color: gold, size: 18), const SizedBox(width: 8), Expanded(child: Text('$home  vs  $away', style: const TextStyle(fontWeight: FontWeight.bold))), Text(time, style: const TextStyle(color: Colors.white60, fontSize: 11))]),
      const SizedBox(height: 14),
      Row(children: [
        _oddButton('1', odds[0], '$home to win'), _oddButton('X', odds[1], 'Draw'), _oddButton('2', odds[2], '$away to win'),
      ]),
    ])),
  );

  Widget _oddButton(String label, String odd, String pick) => Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: OutlinedButton(
    style: OutlinedButton.styleFrom(side: BorderSide(color: gold.withOpacity(.6)), backgroundColor: forest),
    onPressed: () => addPick('$pick (demo odds $odd)'),
    child: Column(children: [Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)), Text(odd, style: const TextStyle(color: gold, fontWeight: FontWeight.bold))]),
  )));

  Widget _gamesPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const _SectionTitle('FREE-PLAY GAMES', subtitle: 'Entertainment only — no cash prizes'),
    _gameTile(Icons.casino, 'Lucky Spin', 'A sample spin game using virtual points'),
    _gameTile(Icons.grid_view, 'Lucky Slots', 'A non-monetary slot-style demo'),
    _gameTile(Icons.style, 'Card Match', 'Match cards and earn demo points'),
    const Padding(padding: EdgeInsets.only(top: 12), child: Text('Games are for free play only. Virtual credits cannot be sold, transferred or exchanged for money.', style: TextStyle(color: Colors.white54, fontSize: 11))),
  ]);

  Widget _gameTile(IconData icon, String name, String detail) => Card(color: const Color(0xFF102B21), child: ListTile(leading: CircleAvatar(backgroundColor: forest, child: Icon(icon, color: gold)), title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(detail), trailing: const Icon(Icons.chevron_right), onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: Text(name), content: const Text('This free-play game screen is a placeholder in the prototype.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))]))));

  Widget _myBetsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const _SectionTitle('MY DEMO SLIP', subtitle: 'Your selections are stored only in this running prototype'),
    if (slip.isEmpty) const Card(color: Color(0xFF102B21), child: Padding(padding: EdgeInsets.all(18), child: Text('No selections yet. Choose a demo outcome in Football.'))),
    ...slip.asMap().entries.map((e) => Card(color: const Color(0xFF102B21), child: ListTile(leading: const Icon(Icons.sports_soccer, color: gold), title: Text(e.value), trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => slip.removeAt(e.key))))),
    if (slip.isNotEmpty) OutlinedButton.icon(onPressed: () => setState(slip.clear), icon: const Icon(Icons.delete_outline), label: const Text('Clear demo slip')),
  ]);

  Widget _adminPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const _SectionTitle('ADMINISTRATION', subtitle: 'Prototype access overview'),
    _adminTile(Icons.person, 'Owner account', 'Full administrator access'),
    _adminTile(Icons.manage_accounts, 'Pretty', 'Manager — restricted permissions'),
    _adminTile(Icons.people, 'User management', 'View demo registrations'),
    _adminTile(Icons.sports_soccer, 'Fixtures & sample odds', 'Manage illustrative demo fixtures'),
    _adminTile(Icons.support_agent, 'Support', 'View sample support requests'),
    const SizedBox(height: 12),
    const Text('Security note: this prototype does not create accounts, send OTP messages, or connect to a database. Admin permissions must be enforced by a secure backend before launch.', style: TextStyle(color: Colors.white54, fontSize: 11)),
  ]);

  Widget _adminTile(IconData icon, String title, String subtitle) => Card(color: const Color(0xFF102B21), child: ListTile(leading: Icon(icon, color: gold), title: Text(title), subtitle: Text(subtitle)));

  void _showAccount() => showModalBottomSheet(context: context, backgroundColor: forest, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('ACCOUNT', style: TextStyle(color: gold, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('Guest demo account'), const Text('Phone + OTP registration will be connected in a later development step.'), const SizedBox(height: 14), FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))]))));
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionTitle(this.title, {required this.subtitle});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 4), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 1.1, fontSize: 15)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12))]));
}
