# Super Kasi Bets — Android free-play prototype

This Flutter prototype contains demo football fixtures, illustrative sample odds, an R150 virtual-credit balance, free-play game placeholders, a demo selection slip, and an Owner/Pretty (Manager) administration overview.

## Build an APK using only an Android phone

This project includes a GitHub Actions workflow that builds the APK in the cloud. You do not need to install Flutter or Android Studio on your phone.

1. Create or sign in to a GitHub account in Chrome at https://github.com.
2. Create a new **public** repository named `super-kasi-bets` (public repositories can use GitHub-hosted Actions without consuming private-repository minutes under the applicable free allowance; GitHub may change its limits).
3. Extract this ZIP on your phone using your Files app or an archive app.
4. On the new GitHub repository, choose **Add file → Upload files** and upload the contents of the extracted `super_kasi_bets` folder, including the hidden `.github` folder and its workflow file. If your phone's file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow from this ZIP.
5. Commit the upload to the `main` branch. The workflow should start automatically. You can also open the **Actions** tab, select **Build Android APK**, and tap **Run workflow**.
6. When the run finishes successfully, open it, scroll to **Artifacts**, and download `super-kasi-bets-android-apk`. Extract the downloaded artifact ZIP to get `app-release.apk`.
7. Tap the APK to install. Android may ask you to allow Chrome or your file manager to install unknown apps. Only enable this for the app you intentionally downloaded, then turn it off again afterward.

## Important limitations

- This is a free-play prototype, not a real-money betting service.
- The R150 is virtual demo credit only. It has no cash value and cannot be deposited, withdrawn, transferred, or exchanged for money.
- No phone OTP, backend database, real account system, live fixtures, real odds, payments, or server-enforced admin permissions are implemented.
- The Owner and Pretty entries are display-only examples, not secure login accounts.
- Do not use this prototype to accept deposits or promise cash prizes. Any real-money gambling product needs appropriate legal and licensing review in South Africa.
